# log in front end

both the log in and the registration will have to be linked together by a link saying that you can navigate to the registration page

## log in page

page will contain a form that the user can input their email and password, this will be sent to an endpoint for the backend to process it \
items will be sent using post method in html form
password will be sent with name password
email will be sent with name email

## registration page

page will allow the user to input email, username, and password
these will be sent to an endpoint on the backend that will proccess the data and create a new account for the user. passwords will have to be entered twice so that we can confirm that they are no typos in the password when registering

items will be sent using the post method
email will be sent with name email
username will be sent with name username
passwords will be sent with name password

## visuals

the page will just contain html forms that the user can use to input the data passwords must be in password fields so that they are not revealed unless explicitly told to by the user