# trello screenshots

this folder is for screenshots of the trello board for this project