from django.contrib import admin
from Resources.models import Resource

# Register your models here.
admin.site.register(Resource)
