import pstats
from django.contrib import admin
from .models import Champion, Item, ChampionItems

admin.site.register(Champion)
admin.site.register(Item)
