# Welcome to the Exeter Orienteering Project

### Group Z
___

The group members are:

1. Adarsh Prusty
2. Alex Baker
3. Alex Williams
4. Lucy Dechaine
5. Tomasso Zanini
6. Zdenek Plesek


This is a submission for Sprint 1. There are three types of document that you will find the following places.

## PROCESS DOCUMENTS
Our process documents are managed in the trello platform and as documents storaed on GitHub. The link to our project page is below. We (plesekz for GitHub and zp235 for Trello specifically) have added mattcollison2 to the board so it is visible.

trello link: https://trello.com/b/YHYMhXX1/group-software-development

We have also taken regular snapshots of the kanban board in trello to archive our progress. These are held in the repository below.

./process-documents/kanban-snapshot/

Within process documents we have also included the meeting notes, agenda and minutes. These will be found in the repository below.

./process-documents/meeting-notes/

## TECHNICAL DOCUMENTS
Our technical documents are primarily managed on the github system. The link to the project is below:

github link: https://github.com/plesekz/ecm2434-Group-Project

We have also include the versioned source code for archiving.

./technical-documents/

## PRODUCT DOCUMENTS
Our product documents are primarily in the form of a product UI. Below is a link to our latest version.

public link: https://www.scavengersofexeter.xyz/

The UI and design documents for the client have also been archived under the link below:

./product-documents/
